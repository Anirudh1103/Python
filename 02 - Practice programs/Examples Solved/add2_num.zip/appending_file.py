with open("test.txt","a") as f:
    f.write("\nI am an Computer Science student")