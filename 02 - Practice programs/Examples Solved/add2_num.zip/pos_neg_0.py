#Python Program to Check if a Number is Positive, Negative or 0
x = int(input("Enter the number to Check if a Number is Positive, Negative or 0: "))

if x > 0:
    print("The number entered is Positive")
elif x < 0:
    print("The number entered is negative")
else:
    print("The number entered is 0")