#Python Program to Convert Kilometers to Miles
km = int(input("Enter the value in Km which needs to be converted to miles: "))
m = km * 0.6213712

print(str(km) + "km = " + str(m) + "m\n")