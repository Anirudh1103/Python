#Python Program to Generate a Random Number
import random
print(random.randint(0,9))

'''Explaination of program  ---->
here first we are importing random module using keyword import  
in the next line we are using print function. Inside print function we are calling random module and
specifying the datatype of the random number to be genrated that is randint and giving limit (0,9)'''