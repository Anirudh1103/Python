#python program to add two numbers
a = int(input("Enter the first number"))
b = int(input("Enter the second number"))
c = a + b

print("Sum = " + str(c))