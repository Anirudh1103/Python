#Python Program to Convert Celsius To Fahrenheit
c = int(input("Enter the temperature in celcius which needs to be converted to *f "))
f = (c/5) * 9 + 32
print(str(c) + "*c = " + str(f) + "*f")