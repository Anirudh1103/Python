with open("test.txt","r") as f:
   txt =  f.read()
   print(txt)

#second way
# # f = open("test.txt","r")
# txt = f.read()
# print(txt)
# f.close()