#Python program to print Hello world
print("Hello World!")