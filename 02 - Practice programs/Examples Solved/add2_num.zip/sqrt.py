#Python program to find square root of a number

x = int(input("Enter the number whose sqrt needs to be found out: "))
sqrt = x ** 0.5
print("sqrt = " + str(sqrt))