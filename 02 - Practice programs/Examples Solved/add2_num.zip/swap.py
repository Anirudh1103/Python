#Python Program to Swap Two Variables
a = str(1)
b = str(2)
print("Before swapping: ")
print("a = " + a,"\nb = " + b)
temp = a
a = b
b = temp
print("After swapping: ")
print("a = " + a,"\nb = " + b)