a = "My name is Anirudh"
# with open("test.txt","w") as f:
#     f.write(a)

f = open("test.txt","w")
f.write(a)
f.close()