x = input("Enter the value of x")
y = input("Enter the value of y")

#swapping
temp = x
x = y
y = temp

print("x = " + x + "\ny = " + y)