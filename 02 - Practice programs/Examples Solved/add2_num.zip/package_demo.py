import pandas
df = pandas.read_excel("file_example_XLSX_10.xlsx")