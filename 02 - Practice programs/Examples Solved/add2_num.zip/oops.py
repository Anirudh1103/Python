class Employee:
    salary = 90000
    def getsalary(self):
        return self.salary
rohan = Employee()
print(rohan.salary)